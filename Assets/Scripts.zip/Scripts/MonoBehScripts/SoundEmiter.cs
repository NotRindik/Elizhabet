using UnityEngine;


public class SoundEmiter : MonoBehaviour
{
    [Header("�����")]
    public EventSoundInstance sound;

    public void Play()
    {
        AudioManager.instance.PlayEvent(sound);
    }
}