using System;
using UnityEngine;
using UnityEngine.Playables;

[RequireComponent(typeof(PlayableDirector))]
public class CutsceneManager : MonoBehaviour
{
    private PlayableDirector director;

    public bool playOnce = true;
    private bool played;

    public string localKey = "CutScene";

    private string Key => WorldKeyBuilder.Build(this,localKey);

    public BetterEvent onEnd;
    public BetterEvent onStart;

    public Action<PlayableDirector> Endhandle;
    public Action<PlayableDirector> StartHandle;

    public bool playOnStart = true;

    private void Awake()
    {
        director ??= GetComponent<PlayableDirector>();
        Endhandle = c => onEnd.Invoke();
        StartHandle = c => onStart.Invoke();
    }
    private void OnEnable()
    {
        director.stopped += Endhandle;
        director.played += StartHandle;
    }

    public void Start()
    {
        var global = SaveManager.Instance.GetModule<GlobalSaves>();
        bool exist = global.Exist(Key);
        if (exist)
            played = global.GetData(Key) == "1";
        else
            played = false;
        
        if(!playOnStart)
            return;
        
        if (playOnce)
        {
            Play(global);
        }
        else
        {
            director.Play();
        }
    }
    private void Play(GlobalSaves global)
    {
        if (played)
            return;
        
        director.Play();
        global.SetData(Key, "1").Save();
    }

    private void OnDisable()
    {
        director.stopped -= Endhandle;
        director.played -= StartHandle;
    }
}