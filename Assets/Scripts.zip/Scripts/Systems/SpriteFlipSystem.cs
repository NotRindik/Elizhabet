using Controllers;
using System;
using UnityEngine;
namespace Systems {
    public class SpriteFlipSystem : BaseSystem
    {
        SpriteFlipComponent spriteFlipComponent;
        WallEdgeClimbComponent _wallEdgeClimbComponent;

        public override bool IsActive
        {
            get => isActive;
            set
            {
                isActive = value;
            }
        }

        public override void Initialize(AbstractEntity owner)
        {
            base.Initialize(owner);
            spriteFlipComponent = owner.GetControllerComponent<SpriteFlipComponent>();
            _wallEdgeClimbComponent = base.owner.GetControllerComponent<WallEdgeClimbComponent>();
            owner.OnUpdate += Update;
            this.owner = owner;
        }
        public override void OnUpdate() 
        {
            if (_wallEdgeClimbComponent != null)
            {
                if (_wallEdgeClimbComponent.EdgeStuckProcess != null)
                {
                    return;
                }
            }
            
            if (spriteFlipComponent.direction.x == -1)
            {
                transform.localScale = new Vector3(-1,1,1);
                spriteFlipComponent.OnFlip?.Invoke(transform.localScale);
            }
            else if (spriteFlipComponent.direction.x == 1)
            {
                transform.localScale = new Vector3(1, 1, 1);
                spriteFlipComponent.OnFlip?.Invoke(transform.localScale);
            }
        }
    }
    [System.Serializable]
    public class SpriteFlipComponent: IComponent
    {
        public Vector2 direction;
        public Action<Vector3> OnFlip;
        
        public bool IsFlip => direction.x == -1;
    }
}