using System;
using Controllers;
using UnityEngine;


namespace Systems
{
    public abstract class AttackTriggerSystem : BaseSystem
    {
        protected AttackComponent attackComponent;
        protected FSMSystem fsmSystem;
        protected InputComponent inputComponent;
        protected AttackAnimationSystem animSystem;
        protected WeaponComponent weaponComponent;
        protected ItemComponent itemComponent;

        protected Item item;

        public override void Initialize(AbstractEntity owner)
        {
            base.Initialize(owner);
            item = (Item)owner;
            animSystem = owner.GetControllerSystem<AttackAnimationSystem>();
            weaponComponent = owner.GetControllerComponent<WeaponComponent>();
            itemComponent = owner.GetControllerComponent<ItemComponent>();
            item.OnReferenceClean += ReferenceClean;
            item.OnTake += HandleEquip;
        }

        private void HandleEquip(AbstractEntity playerOwner)
        {
            attackComponent = playerOwner.GetControllerComponent<AttackComponent>();

            weaponComponent.modifiedDamage = attackComponent.damageModifire.Raw;
            fsmSystem = playerOwner.GetControllerSystem<FSMSystem>();
            inputComponent = item.inputComponent;
            OnEquip();
        }
        
        private void ReferenceClean()
        {
            OnUnequip();
            weaponComponent.modifiedDamage = null;
            attackComponent = null;
            fsmSystem = null;
            inputComponent = null;
        }

        protected abstract void OnEquip();
        protected abstract void OnUnequip();
    }


    public interface IAttackTriggerPolicy
    {
        bool CanTrigger(AbstractEntity attackingItem);
    }

    public class ComboAttackPolicy : IAttackTriggerPolicy
    {
        public bool CanTrigger(AbstractEntity attackingItem)
        {
            var owner = attackingItem.GetControllerComponent<ItemComponent>().currentOwner;
            if (owner == null)
                return false;
            return owner.GetControllerComponent<AttackComponent>().canAttack;
        }
    }
}