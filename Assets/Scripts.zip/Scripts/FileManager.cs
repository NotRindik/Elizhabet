﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts
{
    public static class FileManager
    {
        public static  string Items = "Prefabs/Items/";
        public static string Audio = "Audio/";
        public static string TransitionEffects = "Transition Effects/";
        public static string Prefabs = "Prefabs/";
        public static string SFX = $"{Audio}SFX/";
        public static string WeaponsSFX = $"{Audio}SFX/WeaponsSFX/";
        public static string Music = $"{Audio}Music/";
        public static string Fonts = $"Fonts/";
    }
}
