using UnityEngine;
using UnityEngine.UI;
using Systems;

namespace Controllers
{
    public class HealthUIItem : UIController
    {
        [SerializeField] public Image image;
        

        private HealthComponent _healthComponent;
        private HealthItemUIComponent itemComponent = new HealthItemUIComponent();
        private HealthUIData _uiData;
        

        public void Init(HealthComponent healthComponent,HealthUIData uiData,int itemIndex)
        {
            _healthComponent = healthComponent;
            _uiData = uiData;
            itemComponent.ItemIndex = itemIndex;
            _healthComponent.OnCurrHealthDataChanged += UpdateUI;
            UpdateUI(_healthComponent.currHealth);
        }

        private void UpdateUI(float health)
        {
            float cellHP = Mathf.Clamp(health - ((_uiData.healthes.Count - itemComponent.ItemIndex-1) * 5), 0, 5);
            image.fillAmount = cellHP / 5;
        }

        protected override void ReferenceClean()
        {
            base.ReferenceClean();
            _healthComponent.OnCurrHealthDataChanged -= UpdateUI;
        }
    }
}

namespace Systems
{
    public class HealthItemUIComponent : IComponent
    {
        public float MaxHealth = 5;
        public float CurrHealth = 5;
        public int ItemIndex = 0;
    }    
}
