using Assets.Scripts;
using Controllers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Systems;
using UnityEngine;

public class Item : OptimizedController, IInteractable
{
    public Action<AbstractEntity> OnTake;
    public Action OnThrow;
    public Action OnReferenceClean;
    public Action<Item> OnBreakRequest;

    protected ColorPositioningComponent colorPositioning;

    public List<Type> nonInitComponents = new List<Type>();
    public InputComponent inputComponent;
    public ItemPositioningSystem itemPositioningSystem = new OneHandPositioning();
    public Action itemPositioningHandler;

    public bool isSelected { get; set; }
    public bool EquipeOnStart;
    protected bool InitAfterInventory;
    protected Coroutine DestroyProcess;
    
    public ItemComponent itemComponent => 
        GetControllerComponent<ItemComponent>() ?? GetControllerComponentDirect<ItemComponent>();
    protected ControllersBaseFields baseFields => GetControllerComponent<ControllersBaseFields>();
    protected HealthComponent healthComponent => GetControllerComponent<HealthComponent>();

    protected override IComponent[] DefaultComponents => new IComponent[]{
        new ItemComponent(),
        new ControllersBaseFields{ rb = GetComponent<Rigidbody2D>(), collider =  GetComponents<Collider2D>() }
        ,new HealthComponent()};

    protected override ISystem[] DefaultSystems => new ISystem[]{new HealthSystem()};

    protected virtual void Start()
    {
        if (!InitAfterInventory)
        {
            EnsureInitialized();
        }

        if (EquipeOnStart)
        {
            SelectItem(itemComponent.currentOwner);
        }
    }

    protected override void InitEntity()
    {
        base.InitEntity();
        TryGetPrefabReference();
    }
    private void TryGetPrefabReference()
    {

        if (!PrefabCheacker.IsPrefab(itemComponent.itemPrefab))
        {
            string cleanedName = Regex.Replace(gameObject.name, @"\s*\([^)]*\)$", "");
            itemComponent.itemPrefab = Resources.Load<GameObject>($"{FileManager.Items}{cleanedName}");
        }
    }

    protected override void Awake()
    {
    }

    public virtual void InitAfterSpawnFromInventory(Dictionary<Type, ISaveSerialize> invComponents)
    {
        nonInitComponents.Add(typeof(ControllersBaseFields));

        foreach (var kvp in invComponents)
        {
            if (nonInitComponents.Contains(kvp.Key))
                continue;

            if (kvp.Value is IComponent component)
            {
                Components[kvp.Key] = component;

                for (int i = 0; i < components.Length; i++)
                {
                    if (components[i].GetType() == component.GetType())
                    {
                        components[i] = component;
                    }
                }
            }
        }

        InitAfterInventory = true;

        EnsureInitialized();
        TryGetPrefabReference();
    }

    public virtual void SelectItem(AbstractEntity owner)
    {
        isSelected = true;
        this.colorPositioning = owner.GetControllerComponent<ColorPositioningComponent>();
        itemComponent.currentOwner = owner;
        inputComponent = new InputComponent(owner.GetControllerSystem<IInputProvider>());
        baseFields.rb.bodyType = RigidbodyType2D.Static;

        if (colorPositioning != null)
        {
            itemPositioningSystem = new OneHandPositioning();
            itemPositioningSystem.Initialize(this);
            AddControllerSystem(itemPositioningSystem);
            itemPositioningHandler = () => itemPositioningSystem?.ItemPositioning();
            colorPositioning.AfterColorCalculated.Add(itemPositioningHandler, 3);
        }
        else
        {
            itemPositioningSystem = new ZeroPositioning();
            itemPositioningSystem.Initialize(this);
            AddControllerSystem(itemPositioningSystem);
            itemPositioningHandler = () => itemPositioningSystem?.ItemPositioning();
            OnLateUpdate += itemPositioningHandler;
        }

        foreach (var col in baseFields.collider)
        {
            col.isTrigger = true;
        }
        
        OnTake?.Invoke(owner);
    }

    public virtual void DestroyItem()
    {
        DestroyProcess ??= StartCoroutine(DestroyRoutine());
    }

    public IEnumerator DestroyRoutine()
    {
        yield return new WaitUntil(itemComponent.DestroyCondition);
        OnBreak();
        Destroy(gameObject);
    }

    protected virtual void OnBreak()
    {
        if (itemComponent.breakSound)
            AudioManager.instance.PlayEvent(new EventSoundInstance(itemComponent.breakSound));
        
        OnBreakRequest?.Invoke(this);
    }

    public virtual void Throw(Vector2 dir = default, float force = 15)
    {
        OnThrow?.Invoke();
        baseFields.rb.bodyType = RigidbodyType2D.Dynamic;
        if (dir == default)
            dir = (itemComponent.currentOwner.mono.transform.position - transform.position);

        baseFields.rb.AddForce(dir * force, ForceMode2D.Impulse);
        foreach (var col in baseFields.collider)
        {
            col.isTrigger = false;
        }
        ReferenceClean();
    }

    protected virtual void ReferenceClean()
    {
        if (isSelected)
            isSelected = false;
        else
            return;

        OnReferenceClean?.Invoke();

        inputComponent = null;
        colorPositioning?.AfterColorCalculated.Remove(itemPositioningHandler);
        itemPositioningHandler = null;
        itemPositioningSystem = null;
        itemComponent.currentOwner = null;
        this.colorPositioning = null;
    }

    protected override void OnDestroy()
    {
        base.OnDestroy();
        ReferenceClean();
        OnBreakRequest = null;
        OnReferenceClean = null;
        OnTake = null;
        OnThrow = null;
    }

    void IInteractable.Interact(AbstractEntity interactor)
    {
        var inventory = interactor.GetControllerSystem<InventorySystem>();
        inventory?.SetItem(this);
    }

    public bool CanInteract(AbstractEntity _) => !isSelected && isActiveAndEnabled;
}

[Serializable]
public class ItemComponent : IComponent,ISaveSerialize
{
    public GameObject itemPrefab;
    public AbstractEntity _currentOwner;

    public AbstractEntity currentOwner
    {
        get => _currentOwner;
        set
        {
            if(value == null)
                Debug.Log("Some One Set NULL");
            _currentOwner = value;
        }
    }

    public Sprite itemIcon;
    public int stackSize = 1;
    public EventSound breakSound;
    
    public Func<bool> DestroyCondition = () => true;
    public void ApplyConfig(AbstractEntity config)
    {
        ItemComponent itemConfig = config.GetControllerComponentDirect<ItemComponent>();
        
        if (itemConfig != null)
        {
            itemIcon = itemConfig.itemIcon;
            stackSize = itemConfig.stackSize;
            breakSound = itemConfig.breakSound;
            itemPrefab = itemConfig.itemPrefab;
        }
    }
}

public class InputComponent : IComponent
{
    public InputComponent(IInputProvider input)
    {
        this.input = input;
    }

    public IInputProvider input;
}

public static class PrefabCheacker
{
    public static bool IsPrefab(GameObject obj)
    {
        return obj?.scene.rootCount == 0;
    }
}

public abstract class ItemPositioningSystem : BaseSystem
{
    protected ColorPositioningComponent _colorPositioning;
    protected ItemComponent _itemComponent;
    protected Item _itemOwner;

    public override void Initialize(AbstractEntity owner)
    {
        base.Initialize(owner);
        if (owner is Item item)
            _itemOwner = item;
        else
        {
            UnityEngine.Debug.LogError("Ты суешь не предмет в позиционирование предметов");
            return;
        }
        _itemComponent = _itemOwner.GetControllerComponent<ItemComponent>();
        _colorPositioning = _itemComponent.currentOwner.GetControllerComponent<ColorPositioningComponent>();
    }

    public virtual void ItemPositioning()
    {
        if (_colorPositioning == null)
            return;

        Apply(_colorPositioning, _itemComponent.currentOwner.mono.transform, _itemOwner.transform);
    }

    public virtual void Apply(ColorPositioningComponent cp, Transform ownerT, Transform itemT) { }
}

public class OneHandPositioning : ItemPositioningSystem
{
    public override void Apply(ColorPositioningComponent cp, Transform ownerT, Transform itemT)
    {
        var hand = cp.pointsGroup[ColorPosNameConst.RIGHT_HAND_POS];
        itemT.position = (Vector3)hand.FirstActivePoint() + new Vector3(0, 0, -1);
        var dir = -hand.direction.normalized;
        var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        itemT.rotation = Quaternion.Euler(0, 0, angle);
        itemT.localScale = new Vector3(1, ownerT.FacingSign(), 1);
    }
}

public class OneHandAlongArmPositioning : ItemPositioningSystem
{
    public override void Apply(ColorPositioningComponent cp, Transform ownerT, Transform itemT)
    {
        var hand = cp.pointsGroup[ColorPosNameConst.RIGHT_HAND_POS];
        itemT.position = (Vector3)hand.FirstActivePoint() + new Vector3(0, 0, -1);
        var dir = -hand.direction.normalized;
        var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg - 90;
        itemT.rotation = Quaternion.Euler(0, 0, angle);
    }
}

public class ZeroPositioning : ItemPositioningSystem
{
    public override void ItemPositioning()
    {
        _itemOwner.transform.localPosition = Vector2.zero;
    }

    public override void Apply(ColorPositioningComponent cp, Transform ownerT, Transform itemT)
    {
        itemT.localPosition = Vector2.zero;
    }
}

public class TwoHandPositioning : ItemPositioningSystem
{
    public override void Apply(ColorPositioningComponent cp, Transform ownerT, Transform itemT)
    {
        var rightGroup = cp.pointsGroup[ColorPosNameConst.RIGHT_HAND_POS];
        Vector3 leftHand = cp.pointsGroup[ColorPosNameConst.LEFT_HAND].FirstActivePoint();
        Vector3 rightHand = rightGroup.FirstActivePoint();
        var facing = ownerT.FacingSign();

        if (leftHand == Vector3.zero)
        {
            itemT.position = rightHand;
            var dir = -rightGroup.direction.normalized;
            var a = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
            itemT.rotation = Quaternion.Euler(0, 0, a);
            itemT.localScale = new Vector3(1, facing, 1);
            return;
        }

        itemT.position = rightHand + new Vector3(0, 0, -1);
        Vector2 along = (rightHand - leftHand) * facing;
        var angle = Mathf.Atan2(along.y, along.x) * Mathf.Rad2Deg;
        itemT.rotation = Quaternion.Euler(0, 0, angle + 90f);
        itemT.localScale = new Vector3(1, facing, 1);
    }
}

[Serializable]
public class RarityComponent : IComponent
{
    public Rarity rarity;
    public enum Rarity
    {
        Common, Uncommon, Rare, Elite, Epic, Legendary, Cult, Cum, Cursed
    }

    public static readonly Dictionary<Rarity, string> RarityNames = new()
    {
        { Rarity.Common, "Common" },
        { Rarity.Uncommon, "Uncommon" },
        { Rarity.Rare, "Rare" },
        { Rarity.Elite, "Elite" },
        { Rarity.Epic, "Epic" },
        { Rarity.Legendary, "Legendary" },
        { Rarity.Cum, "Cuming" },
        { Rarity.Cult, "Cult Weapon" },
        { Rarity.Cursed, "Cursed Weapon" }
    };
}