using System;
using System.Collections.Generic;
using System.Linq;
using Systems;
using UnityEngine;

public class OptimizedController : AbstractEntity
{
    [SerializeReference, SubclassSelector]
    public IComponent[] components = Array.Empty<IComponent>();

    [SerializeReference, SubclassSelector]
    public ISystem[] systems = Array.Empty<ISystem>();

    private bool _isInitialized;

    protected virtual void Awake()
    {
        mono = this;
        EnsureInitialized();
    }
    
    public void EnsureInitialized()
    {
        if (_isInitialized)
            return;

        _isInitialized = true; 
        InitEntity();
    }
    
    protected virtual void InitEntity()
    {

        BuildInfrastructure();
        InitSystems();
    }

    protected virtual IComponent[] DefaultComponents { get; private set; }
    protected virtual ISystem[] DefaultSystems { get; private set; }

    protected virtual void Update() => OnUpdate?.Invoke();
    protected virtual void FixedUpdate() => OnFixedUpdate?.Invoke();
    protected virtual void LateUpdate() => OnLateUpdate?.Invoke();

    private void BuildInfrastructure()
    {
        if (components != null && components.Length > 0)
        {
            Components = new Dictionary<Type, IComponent>(components.Length);
            foreach (var c in components)
            {
                if (c == null) continue;
                Components[c.GetType()] = c;
            }
        }

        if (systems != null && systems.Length > 0)
        {
            Systems = new Dictionary<Type, ISystem>(systems.Length);
            foreach (var s in systems)
            {
                if (s == null) continue;
                Systems[s.GetType()] = s;
            }
        }
    }
    
    private void OnValidate()
    {
        if (components == null || components.Length == 0)
        {
            if(DefaultComponents != null)
                components = DefaultComponents;
        }

        if (systems == null || systems.Length == 0)
        {
            if(DefaultSystems != null)
                systems = DefaultSystems;
        }
    }

    private void InitSystems()
    {
        if (Systems == null) return;

        foreach (var system in Systems.Values)
            system.Initialize(this);
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        OnCollisionEnter2DHandle?.Invoke(other);
    }

    public override void AddControllerComponent<T>(T component)
    {
        Components ??= new Dictionary<Type, IComponent>(4);
        Components[typeof(T)] = component;
    }

    public override void AddControllerSystem<T>(T system)
    {
        Systems ??= new Dictionary<Type, ISystem>(2);
        Systems[typeof(T)] = system;
        system.Initialize(this);
    }

    public override T GetControllerComponentDirect<T>() => (T)components.FirstOrDefault(el => el is T);
    public override T GetControllerComponent<T>()
    {
        EnsureInitialized();
        if (Components == null) return default;
        return Components.TryGetValue(typeof(T), out var c)
            ? (T)c
            : default;
    }

    public override T GetControllerSystem<T>()
    {
        EnsureInitialized();
        if (Systems == null) return null;

        if (Systems.TryGetValue(typeof(T), out var exact))
            return exact as T;

        foreach (var sys in Systems.Values)
            if (sys is T match)
                return match;

        return null;
    }

    protected virtual void OnDestroy()
    {
        if (Systems == null) return;

        foreach (var sys in Systems.Values)
            if (sys is IDisposable d)
                d.Dispose();
    }

    public void Destroy() => Destroy(gameObject);


    public override bool ExistSys<T>()
    {
        EnsureInitialized();
        return Systems.ContainsKey(typeof(T));
    }

    public override bool ExistCom<T>()
    {
        EnsureInitialized();
        return Components.ContainsKey(typeof(T));
    }
}
