﻿using System.Collections;
using Controllers;
using UnityEngine;

namespace Systems
{
    public class PlatformSystem: BaseSystem
    {
        private PlatformComponent _platformComponent;
        private GroundingComponent _groundingComponent;
        private ControllersBaseFields _baseFields;
        public override void Initialize(AbstractEntity owner)
        {
            base.Initialize(owner);
            _groundingComponent = owner.GetControllerComponent<GroundingComponent>();
            _baseFields = owner.GetControllerComponent<ControllersBaseFields>();
            _platformComponent = owner.GetControllerComponent<PlatformComponent>();
        }

        public override void OnUpdate()
        {
            base.OnUpdate();

            for (int i = 0; i < _groundingComponent.count; i++)
            {
                if (_groundingComponent.groundedColliders[i].TryGetComponent(out PlatformEffector2D _))
                {
                    _platformComponent.IgnoreProcess = mono.StartCoroutine(IgnoreCollisionProcess(_groundingComponent.groundedColliders[i]));
                }
            }
        }

        private IEnumerator IgnoreCollisionProcess(Collider2D col)
        {
            yield return new WaitForFixedUpdate();
            foreach (var entityCol in _baseFields.collider)
            {
                Physics2D.IgnoreCollision(col,entityCol,true);   
            }
            _baseFields.rb.linearVelocity = new Vector2(_baseFields.rb.linearVelocity.x, -0.1f);
            yield return new WaitForSeconds(_platformComponent.unCollisionTime);
            foreach (var entityCol in _baseFields.collider)
            {
                Physics2D.IgnoreCollision(col,entityCol,false);   
            }
            _platformComponent.IgnoreProcess = null;
        } 
    }

    [System.Serializable]
    public class PlatformComponent : IComponent
    {
        public float unCollisionTime = 0.2f;
        public Coroutine IgnoreProcess;
    }
}