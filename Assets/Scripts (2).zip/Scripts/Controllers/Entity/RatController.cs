using Assets.Scripts;
using AYellowpaper.SerializedCollections;
using Controllers;
using System;
using System.Collections;
using Systems;
using UnityEngine;
using UnityEngine.Events;


public class RatController : EntityController
{
    private MoveSystem _moveSystem = new MoveSystem();
    private SpriteFlipSystem _flipSystem = new SpriteFlipSystem();
    private RotationToFootSystem _rotationToFootSystem = new RotationToFootSystem();
    private GroundingSystem _groundingSystem = new GroundingSystem();
    private ContactDamageSystem _contactDamageSystem = new ContactDamageSystem();
    
    public MoveComponent MoveComponent;
    public AnimationComponent AnimationComponent;
    public SpriteFlipComponent FlipComponent = new SpriteFlipComponent();
    public TransformPositioning transformPositioning = new TransformPositioning();
    public RatInputLogic.RatInputComponent ratInputComponent = new RatInputLogic.RatInputComponent();
    public BaseAttackComponent attackComponent = new BaseAttackComponent();
    public RotationToFootComponent rotationToFoot = new RotationToFootComponent();
    public GroundingComponent groundingComponent = new GroundingComponent();
    public ParticleComponent particleComponent;
    public IInputProvider InputProvider = new RatInputLogic();

    public Action<HitInfo> TakeDamageHandler;
    protected override void Awake()
    {
        MoveComponent.autoUpdate = true;
        base.Awake();
        SubInputs();
        TakeDamageHandler = (where) =>
        {
            var hitParticle = Instantiate(particleComponent.hitParticlePrefab,(Vector3)where.GetHitPos(),Quaternion.identity);
            var bloodParticle = Instantiate(particleComponent.bloodParticlePrefab,(Vector3)where.GetHitPos(),Quaternion.identity);
            hitParticle.Emit(5);
            bloodParticle.Emit(20);
            StartCoroutine(OnHitProcess());
        };
        
        healthComponent.OnTakeHit += TakeDamageHandler;
        _contactDamageSystem.OnContactDamage += OnContactDamage;
    }

    public void OnContactDamage()
    {
        InputProvider.GetState().Move.Update(true, new Vector2(MoveComponent.direction.x * -1,MoveComponent.direction.y));
    }
    
    public void SubInputs()
    {
        InputProvider.GetState().Move.performed += c =>
        {
            var val = c.ReadValue<Vector2>();
            if (!groundingComponent.isGround)
                return;
            MoveComponent.direction = val;
            FlipComponent.direction = (int)val.x;
        };
        InputProvider.GetState().Move.canceled += c =>
        {
            var val = c.ReadValue<Vector2>();
            if (!groundingComponent.isGround)
                return;
            MoveComponent.direction = val;
            FlipComponent.direction = (int)val.x;

        };
    }

    public IEnumerator OnHitProcess()
    {
        yield return StopMove(0.3f);
        yield return StopMoveUntil(() => groundingComponent.isGround);
    }
    protected override void ReferenceClean()
    {
        healthComponent.OnTakeHit -= TakeDamageHandler;
        _contactDamageSystem.OnContactDamage -= OnContactDamage;
    }
    public IEnumerator StopMove(float duration)
    {
        _moveSystem.IsActive = false;
        yield return new WaitForSeconds(duration);
        _moveSystem.IsActive = true;
    }
    public IEnumerator StopMoveUntil(Func<bool> f)
    {
        _moveSystem.IsActive = false;
        yield return new WaitUntil(f);
        _moveSystem.IsActive = true;
    }

}

[Serializable]
public class BaseAttackComponent : IComponent
{
    public LayerMask attackLayer;
    public DamageComponent damage;
    public float knockBackForce;
    public float knockBackForceVertical;
    public UnityEvent<HitInfo> OnAttackApplied;
    public UnityEvent<HitInfo> OnHitAnything;
    
    public static bool IsInLayerMask(GameObject obj, LayerMask mask)
    {
        return (mask.value & (1 << obj.layer)) != 0;
    }
}

public class ContactDamageSystem : BaseSystem,IDisposable
{
    private BaseAttackComponent _attackComponent;
    
    public Action OnContactDamage;
    private ControllersBaseFields _baseFields;
    
    private Collider2D[] _overlapBuffer;
    private ContactFilter2D filter;
    
    public override void Initialize(AbstractEntity owner)
    {
        base.Initialize(owner);
        _attackComponent = owner.GetControllerComponent<BaseAttackComponent>();
        _baseFields = owner.GetControllerComponent<ControllersBaseFields>();
        
        filter = new ContactFilter2D();
        filter.SetLayerMask(_attackComponent.attackLayer);
        filter.useTriggers = true;
        _overlapBuffer = new Collider2D[16];
        
        owner.OnUpdate += Update;
    }
    public override void OnUpdate()
    {
        bool isHaveHitBox = false;
        for (int i = 0; i < _baseFields.collider.Length; i++)
        {
            Collider2D collider = _baseFields.collider[i];

            if (collider == null || !collider.enabled)
                continue;

            int count = collider.Overlap(filter, _overlapBuffer);

            for (int j = 0; j < count; j++)
            {
                Collider2D targetCollider = _overlapBuffer[j];

                if (targetCollider.TryGetComponent(out HitBoxContext hitBoxe))
                {
                    ContactDamage(hitBoxe.Entity,targetCollider);
                }
                else if (targetCollider.TryGetComponent(out AbstractEntity target) && !isHaveHitBox)
                {
                    var hitBC = target.GetControllerComponent<HitBoxesComponent>();
                    if (hitBC != null && hitBC.IsHitboxExist)
                    {
                        isHaveHitBox = true;
                    }
                    else
                    {
                        ContactDamage(target,targetCollider);
                    }
                }
            }
        }
    }
    public void ContactDamage(AbstractEntity target,Collider2D targetCollider)
    {
        if (!IsActive)
            return;
        
        var point = targetCollider.ClosestPoint(target.transform.position);
        
        var dmgInfo = new HitInfo{ Attacker = owner, hitPosition = point };
        
        var healthSystem = target.GetControllerSystem<HealthSystem>();
        if (healthSystem != null)
        {
            dmgInfo.Target = target;
            new EnemyDamage(_attackComponent.damage).ApplyDamage(healthSystem,ref dmgInfo);
            Vector2 knockDir = ((Vector2)target.transform.position - point).normalized;
            knockDir.Normalize();
                    
            Debug.Log(knockDir);
            OnContactDamage?.Invoke();
            _attackComponent.OnAttackApplied?.Invoke(dmgInfo);
        }
        _attackComponent.OnHitAnything?.Invoke(dmgInfo);
    }
    
    public void Dispose()
    {
        owner.OnUpdate -= Update;
    }
}

public class RotationToFootSystem : BaseSystem,IDisposable
{
    private ControllersBaseFields _baseFields;
    private Rigidbody2D rb => _baseFields.rb;

    private RotationToFootComponent _rotationToFootComponent;

    public override void Initialize(AbstractEntity owner)
    {
        base.Initialize(owner);
        _rotationToFootComponent = base.owner.GetControllerComponent<RotationToFootComponent>();
        _baseFields = base.owner.GetControllerComponent<ControllersBaseFields>();
        owner.OnUpdate += Update;
    }

    public override void OnUpdate()
    {
        base.OnUpdate();
        
        if (IsUpsideDown())
        {
            float targetAngle = 0f;
            float currentAngle = rb.rotation;
            float newAngle = Mathf.LerpAngle(currentAngle, targetAngle, Time.fixedDeltaTime * _rotationToFootComponent.gravityStrength);
            rb.MoveRotation(newAngle);

        }
    }
    bool IsUpsideDown()
    {
        return Mathf.Abs(Mathf.DeltaAngle(rb.rotation, 0f)) > 45f;
    }

    public void Dispose()
    {
        owner.OnUpdate -= Update;
    }
}
[Serializable]
public struct RotationToFootComponent : IComponent
{
    public float gravityStrength;
}

public class RatInputLogic : IInputProvider, IDisposable
{
    private InputState InputState = new InputState();
    private MoveComponent moveComponent;
    private AnimationComponent AnimationComponent;
    private RatInputComponent ratInputComponent;
    private AbstractEntity owner;
    private TransformPositioning transformPositioning;

    private MonoBehaviour _mono;

    public void Dispose()
    {
        owner.OnUpdate -= OnUpdate;
    }

    public InputState GetState()
    {
        return InputState;
    }
    public void SetState(InputState state)
    {
        InputState = state;
    }

    public void Initialize(AbstractEntity owner)
    {
        this.owner = owner;
        moveComponent = owner.GetControllerComponent<MoveComponent>();
        transformPositioning = owner.GetControllerComponent<TransformPositioning>();
        AnimationComponent = owner.GetControllerComponent<AnimationComponent>();
        ratInputComponent = owner.GetControllerComponent<RatInputComponent>();
        _mono = ((MonoBehaviour)owner);
        _mono.StartCoroutine(AIProcess());

        owner.OnGizmosUpdate += OnDrawGizmos;
    }

    public void OnUpdate()
    {
    }

    private IEnumerator AIProcess()
    {
        var input = new Vector2(UnityEngine.Random.Range(-1, 1) == -1 ? -1 : 1, 0);
        InputState.Move.Update(true, input);
        while (true)
        {
            yield return null;

            RaycastHit2D hit = Physics2D.Raycast(transformPositioning.transformPos[ColorPosNameConst.HEAD].position,
                Vector2.right * _mono.transform.FacingSign(), ratInputComponent.headDist, ratInputComponent.layer);

            RaycastHit2D hitGround = Physics2D.Raycast(transformPositioning.transformPos[ColorPosNameConst.HEAD].position,
                Vector2.down, ratInputComponent.ratDist, ratInputComponent.layer);

            if (hit.collider != null || hitGround.collider == null)
            {
                var vector = InputState.Move.ReadValue<Vector2>();
                input.x = vector.x * -1;
                InputState.Move.Update(true, input);
            }

            if (InputState.Move.ReadValue<Vector2>().x == 0)
            {
                if(AnimationComponent.currentState != "Idle")AnimationComponent.CrossFade("Idle",0.1f);
                InputState.Move.Update(true, input);
            }
            else
            {
                if(AnimationComponent.currentState != "Run")AnimationComponent.CrossFade("Run", 0.1f);
            }
        }
    }
    [Serializable]
    public class RatInputComponent : IComponent
    {
        public LayerMask layer;
        public float headDist;
        public float ratDist = 1;
    }

    public void OnDrawGizmos()
    {
        Gizmos.DrawRay(transformPositioning.transformPos[ColorPosNameConst.HEAD].position,Vector2.right * _mono.transform.FacingSign() * ratInputComponent.headDist);
        Gizmos.DrawRay(transformPositioning.transformPos[ColorPosNameConst.HEAD].position,Vector2.down * ratInputComponent.ratDist);
    }
}

[Serializable]
public class TransformPositioning : IComponent
{
    public SerializedDictionary<ColorPosNameConst, Transform> transformPos = new SerializedDictionary<ColorPosNameConst, Transform>();
}

[Serializable]
public class WallStickComponent : IComponent
{
    public float stickForce = 10f;
}

public class WallStickSystem : BaseSystem
{
    private WallStickComponent _wallStickComponent;
    private ControllersBaseFields _controllersBase;
    private Vector2 surfaceNormal = Vector2.up;

    public override void Initialize(AbstractEntity owner)
    {
        base.Initialize(owner);
        _wallStickComponent = owner.GetControllerComponent<WallStickComponent>();
        _controllersBase = owner.GetControllerComponent<ControllersBaseFields>();
        owner.OnFixedUpdate += Update;
        owner.OnGizmosUpdate += OnDrawGizmos;
    }

    public override void OnUpdate()
    {

        Vector2 tangent = new Vector2(-surfaceNormal.y, surfaceNormal.x);

        // ���������������� � �����������
        _controllersBase.rb.AddForce(-surfaceNormal * _wallStickComponent.stickForce);

        // ������ raycast "�����" � "����", ����� ����� ����� ����
        RaycastHit2D hit = Physics2D.Raycast(transform.position + (Vector3)tangent * 0.5f, -tangent, 0.6f);
        if (hit.collider != null)
        {
            surfaceNormal = hit.normal;
            // ��������� ����� ��������� (�������������)
            float angle = Mathf.Atan2(surfaceNormal.y, surfaceNormal.x) * Mathf.Rad2Deg;
            transform.SetZRotation(angle - 90); // ������ ��� ������
        }
    }

    public void OnDrawGizmos()
    {
        Vector2 tangent = new Vector2(-surfaceNormal.y, surfaceNormal.x);
        Gizmos.DrawRay(transform.position + (Vector3)tangent * 0.5f, -tangent* 0.6f);
    }

}